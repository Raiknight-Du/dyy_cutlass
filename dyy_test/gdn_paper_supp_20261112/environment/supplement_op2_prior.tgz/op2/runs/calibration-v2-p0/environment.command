nvidia-smi -q
